package com.msaif.snookertracker;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
