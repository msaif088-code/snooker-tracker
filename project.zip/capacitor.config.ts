import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.msaif.snookertracker',
  appName: 'Snooker Tracker',
  webDir: 'www'
};

export default config;
